JUMP 'N BUMP by Brainchild Design, 1998
Playstation 2 version by Gil Megidish, 2006

Thank you for downloading Jump 'n Bump PS2. This port
follows the sdl version, with several minor changes:

* Two-players without multitap
* Up to 4-players with multitap
* Highscore screen has been removed
* Flies sound effect has been disabled
* Level has been embedded into ELF, for MC-homebrew users
* Press START to return to the main screen

A Quick FAQ:

1. All the bunnies must jump over the tree log. Only bunnies who have done so
   will appear in the game screen.

2. If you are using mtap, all gamepads have to be connected to that adapter.
   Up to 4 players are supported. Connecting two multitaps will result in only
   the first being used. A gamepad connected to another port while a multitap
   is used, will be ignored.

3. Yes, it is not much of a game if you have only one controller..

If you have any questions or suggestions for future versions, please visit 
http://www.megidish.net/jnb/

Jump 'n Bump is being maintained by the guys at 
http://jumpbump.mine.nu
